#!/bin/bash

#ml intel/2018b
#ml netCDF/4.6.1-intel-2018b
#ml netCDF-C++4/4.3.0-intel-2018b
#ml CMake/3.12.1-GCCcore-7.3.0

./guess -input cf global_cf.ins
