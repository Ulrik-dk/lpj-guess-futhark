Fire C-emissions per GFED region: LPJ-GUESS vs GFED. Units: Pg C/y
Giglio et al. 2013, "Analysis of daily, monthly, and annual burned area using thefourth-generation global fire emissions database (GFED4)", doi:10.1002/jgrg.20042

Forest Carbon Pools compared to Pan_et_al. regional dataset for 2007. Units: Pg C
Pan et al. 2011, "A large and persistent Carbon sink in the World's forests", doi:10.1126/science.1201609
