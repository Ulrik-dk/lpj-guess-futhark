NPROCESS=28
if [[ $ARCH == "aurora" ]]; then
    NPROCESS=80
fi
