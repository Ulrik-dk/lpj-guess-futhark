NPROCESS=10
if [[ $ARCH == "aurora" ]]
then
    NPROCESS=40
fi
