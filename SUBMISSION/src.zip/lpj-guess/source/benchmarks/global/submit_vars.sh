NPROCESS=20
if [[ $ARCH == "aurora" ]]
then
    NPROCESS=80
fi
