Reference-data source:
FLUXNET2015 Dataset - Fluxdata from fluxnet.fluxdata.org (https://fluxnet.fluxdata.org/data/fluxnet2015-dataset/)
June 2018.
