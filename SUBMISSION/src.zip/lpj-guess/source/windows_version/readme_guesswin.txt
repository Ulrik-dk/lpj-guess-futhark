guesswin.exe

Because of large size, guesswin.exe is not stored in the svn repository.

Instead it can be dowloaded from here
http://stormbringer.nateko.lu.se/public/download/f82dff0695eda/guess_download/

For release version 4.0, here is a direct link:
http://stormbringer.nateko.lu.se/public/download/f82dff0695eda/guess_download/guesswin.exe_release4.0.zip

For earlier versions of LPJ-GUESS, on the page above, download the whole LPJ-GUESS package, and copy the guesswin.exe from the windows_version catalog of the package.

Please note:
The path to the download page above is updated from time to time. There may be a lag until the path is updated here in this present file in svn. Therefore, if the path does not work for you, ask Johan for the new path to the download page and add /guesswin.exe_release4.0.zip to the end of the path to download guesswin.exe.